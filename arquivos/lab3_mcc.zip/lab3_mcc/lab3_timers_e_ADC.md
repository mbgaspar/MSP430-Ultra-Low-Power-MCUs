# LABORATÓRIO DE MICROCONTROLADORES: TEMPORIZADORES E CONVERSOR ANALÓGICO DIGITAL

## Ariane Andréia Martins
## Ednei Freiberger
---
# Item 1
# a) 
## t = 104 us      
## f = 9,615 Hz       
## prescaler: 128
## A frequência de amostragem foi de 9615 Hz. Para obter o valor de t, dentro da rotina da interrupção do ADC foi utilizada uma função para complementar o valor da saída toda vez que terminasse uma conversão. Assim foi medido o intervalo de tempo entre uma borda e outra da onda de saída (entre a borda de subida e a borda seguinte que era de descida).
## Utilizando um potenciômetro, variou-se a tensão de entrada do AD e, com isso, percebeu-se que a frequência de amostragem não era alterada. Logo, a frequência de amostragem não depende do valor da tensão de entrada do AD, mas da frequência de clock do microcontrolador e do prescaler do AD.

![Figura 1 - Amostragem prescaler 128](lab3_1a_128.bmp)

# b)
## Após variar as configurações do prescaler, percebeu-se que não é possível utilizar qualquer frequência no prescaler, pois o AD possui uma faixa de tempo (13us - 260 us, conforme fabricante) dentro da qual consegue realizar uma conversão. Dependendo do prescaler utilizado e da frequência do microcontrolador, o tempo obtido é menor do que o necessário para o correto funcionamento do AD.
---
## prescaler: 2
## f = 431 kHz
## t = 2,32 us
## Com prescaler de 2 e 16 MHz no ATmega, o AD não funciona corretamente.
---
## prescaler: 4
## f = 303 kHz
## t = 3,3 us
## Com prescaler de 4 e 16 MHz no ATmega, o AD não funciona corretamente.

![Figura 1 - Amostragem prescaler 4](lab3_1b_4.bmp)  

---

## prescaler: 8
## f = 151,1 kHz
## t = 6,6 us
## Com prescaler de 4 e 16 MHz no ATmega, o AD não funciona corretamente.
---
## prescaler: 16
## f = 76,92 kHz
## t = 13,0 us
## Com prescaler de 16 e 16 MHz no ATmega, o AD entra na faixa de funcionamento. Ele faz as conversões, mas está no limite de funcionamento, podendo haver erros na conversão.
---
## prescaler: 32
## f = 38,46 kHz
## t = 26,0 us
## Com prescaler de 32 e 16 MHz no ATmega, o AD já está dentro da faixa de funcionamento. Ele consegue operar corretamente.

![Figura 1 - Amostragem prescaler 4](lab3_1b_32.bmp)   
----
# Item 2
 ## prescaler do timer 0: 1024 (timer em modo normal)

# a)
 ## prescaler do ADC: 128 
 ## latência: 110 us
 ## f = 9091 kHz

 ## O tempo de conversão foi de 110 us e, o tempo calculado foi de:
 ## t = (128 * 13)/ 16000000 = 104 us.

## Utilizando o trigger do ADC pelo timer o tempo de conversão foi um pouco maior, mas utilizando o trigger através do timer se obtém regularidade na amostragem do ADC.

![Figura 1 - Amostragem prescaler 4](lab3_2a_128.bmp) 


# b) 
## A frequência de amostragem da aplicação é a frequência do timer 0, 
## f = 60,98 Hz (valor medido). 
## f = 16000000 / (1024 * 256)= 61,035 Hz 
## A frequência não muda com a variação da tensão na entrada AD.

![Figura 1 - Amostragem prescaler 4](lab3_2b_128.bmp)  

## c) Como citado na letra 'b' do item 1, existe a faixa de tempo de funcionamento do AD (13 us - 260 us). Tanto a configuração de prescaler do timer quanto do prescaler do AD, devem resultar em uma frequência que se mantenha na faixa de funcionamento.
## Na imagem abaixo o timer está sem prescaler, ou seja sem divisão de frequência e o AD não funcionou.
![Figura 1 - Amostragem prescaler 4](lab3_2c.bmp)




