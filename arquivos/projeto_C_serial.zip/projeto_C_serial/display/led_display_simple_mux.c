/*
 * led_display_simple_mux.c
 *
 *  Created on: Mar 20, 2018
 *      Author: xtarke
 */

#include <stdint.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include "../lib/avr_gpio.h"

#include "led_display_simple_mux.h"

/* Esqueleto da estrutura para guardar as configura��es */
typedef struct displays {
	uint8_t total;
	uint8_t atual;
} displays_t;

/* Inst�ncia da struct para manter as configura��es */
displays_t displays_info;

/* Tabela de convers�o em flash */
#ifdef COM_ANODO
const uint8_t convTable[] PROGMEM = {0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02,
		0x78, 0x00, 0x18, 0x08, 0x03, 0x46, 0x21, 0x06, 0x0E};
#endif

/* Tabela de convers�o em flash: Catodo comum */
/*#ifdef COM_CATODO
const uint8_t convTable[] PROGMEM = { 0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D,
		0x07, 0x7F, 0x67, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71 };
#endif*/


void displaysInit(void){

	/* Vari�veis de controle */
	displays_info.total = DISPLAYS;

	/* Todos os pinos como sa�da */
	 DISPLAY_DATA_PORT->DDR =  0xff;
	 DISPLAY_MUX_PORT->DDR =  0b00000011;


}


void displaysWrite(uint8_t hexValue){

	uint8_t i;
	uint8_t data = hexValue;

	for (i = 0; i <displays_info.total; i++){


		DISPLAY_MUX_PORT->PORT =0xff;
		/* M�scaras para pegar somente um d�gito */
		data = (0x0f & hexValue);
		data = pgm_read_byte(&convTable[data]);

		/* Liga os segmentos atrav�s da estrutura
		 * de configura��o inicializada em displaysInit
		 * Portas s�o passadas por refer�ncia 	 */
		DISPLAY_DATA_PORT->PORT = data;
      GPIO_SetBit(DISPLAY_MUX_PORT, i);


		/* Obt�m pr�ximo d�gito  */
		hexValue = hexValue >> 4 ;
		_delay_ms(10);

		/* Desligar os displays */
		//DISPLAY_MUX_PORT->PORT &= ~(1<<i);
		 GPIO_ClrBit(DISPLAY_MUX_PORT, i);


	}
}
