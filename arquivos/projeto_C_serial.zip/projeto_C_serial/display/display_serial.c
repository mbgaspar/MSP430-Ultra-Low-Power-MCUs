/*
 * led_display_simple_mux.c
 *
 *  Created on: Mar 20, 2018
 *      Author: xtarke
 */

#include <stdint.h>
#include <avr/pgmspace.h>
#include <util/delay.h>
#include "../lib/avr_gpio.h"

#include "display_serial.h"



/* Tabela de convers�o em flash */
#ifdef COM_ANODO_SERIAL
const uint8_t conv[] PROGMEM = {0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02,
		0x78, 0x00, 0x18, 0x08, 0x03, 0x46, 0x21, 0x06, 0x0E};
#endif

/* Tabela de convers�o em flash: Catodo comum */
#ifdef COM_CATODO_SERIAL
const uint8_t conv[] PROGMEM = { 0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D,
		0x07, 0x7F, 0x67, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71 };
#endif


void displays_serial_Init(void){


	/* Todos os pinos como sa�da */
	 DISPLAY_SERIAL_PORT->DDR =  0b000000111;
}


void displays_Serial_Write(uint8_t hexValue){

	uint8_t i, bit;
	uint8_t data = hexValue;

	for(i=0;i<2;i++)
	{
		/* M�scaras para pegar somente um d�gito */
		data = (0x0f & hexValue);
		data = pgm_read_byte(&conv[data]);
		data= data<<1;

		for(bit=8; bit>0; --bit)
		{
			 if(TST_BIT(data,bit))
				 GPIO_SetBit(DISPLAY_SERIAL_PORT, DISPLAY_DATA); //display_DATA= PB0
			 else
				 GPIO_ClrBit(DISPLAY_SERIAL_PORT, DISPLAY_DATA);

			 CLOCK();


		}



		/* Obt�m pr�ximo d�gito  */
		hexValue = hexValue >> 4 ;


	}

	STROBE();
}

void CLOCK(void)
{
	 GPIO_SetBit(DISPLAY_SERIAL_PORT, DISPLAY_CLK);
	 _delay_ms(10);
	 GPIO_ClrBit(DISPLAY_SERIAL_PORT, DISPLAY_CLK);

}

void STROBE(void)
{
	 GPIO_SetBit(DISPLAY_SERIAL_PORT, DISPLAY_STB);
	 _delay_ms(10);
	 GPIO_ClrBit(DISPLAY_SERIAL_PORT, DISPLAY_STB);
}
