/*
 * leddisplay.h
 *
 *  Created on: Aug 20, 2018
 *      Author: Renan Augusto Starke
 *      Instituto Federal de Santa Catarina
 */

#include "../lib/bits.h"

#ifndef DISPLAY_LEDDISPLAY_H_
#define DISPLAY_LEDDISPLAY_H_

#define COM_ANODO_SERIAL
//#define COM_CATODO_SERIAL

#define DISPLAY_SERIAL_PORT GPIO_B
#define DISPLAY_DATA PB0
#define DISPLAY_CLK PB1
#define DISPLAY_STB PB2

/**
  * @brief  Configura hardware.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void displays_serial_Init();

/**
  * @brief  Escrevre no display de 7 segmentos.
  * @param	data: valor sem decimal sem conversão. Dados
  * 			são convertidos internamente.
  *
  * @retval Nenhum.
  */
void displays_Serial_Write(uint8_t hexValue);

void CLOCK(void);
void STROBE(void);

#endif /* DISPLAY_LEDDISPLAY_H_ */
