/*
 * 01_main_simple_gpio.c
 *
 *  Created on: Aug 16, 2018
 *      Author: Renan Augusto Starke
 *      Instituto Federal de Santa Catarina
 */


/* Bibliotecas C e AVR */
#include <avr/io.h>
#include <util/delay.h>

/* Bibliotecas customizadas */
#include "lib/avr_gpio.h"
#include "lib/bits.h"

#include "display/display_serial.h"


#define BTN_PORT GPIO_C
#define BTN_PIN PC0



/**
  * @brief  Configura hardware.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void hardware_init(){

	/* Acesso direto: PB0 como saída demais como entrada
	 * como no assembly */
	//DDRB = 0b00000001;
	/* Pull ups */
	//PORTB = 0b00000010;

	/* OU */

	/* Acesso por struct:
	 * Vantagem da estrutura: agrupamento
	 * dos registradores do periférico */

	GPIO_C->PORT = SET(BTN_PIN); //ativando pullup

	/* OU */

	/* Melhor documentação: macros */
	//LED_PORT->DDR = SET(LED_PIN);
	//BTN_PORT->PORT = SET(BTN_PIN);
}


int main(){

	uint8_t data=0x00;
	hardware_init();
	displays_serial_Init();
	displays_Serial_Write(data);
	STROBE();

	while(1)
	{

		while(GPIO_PinTstBit(GPIO_C,PC0))
		{

		}


		//display----------------------
		_delay_ms(100);
		     data++;
		     displays_Serial_Write(data);
		 	STROBE();


		//-------------------------------


	}


	return 0;

}
