/*
 * teclado_hex.c
 *
 *  Created on: 15 de mai de 2019
 *      Author: Tanaka
 */

#include <avr/io.h>
#include <stdio.h>
#include <stdint.h>
#include <avr/pgmspace.h>
#include <util/delay.h>

#include "lib/bits.h"
#include "lib/avr_gpio.h"
#include "lib/avr_timer.h"
#include "teclado_matricial.h"

const uint8_t teclado[4][3] PROGMEM = { {'1', '2', '3'},
										{'4', '5', '6'},
										{'7', '8', '9'},
										{'*', '0', '\n'}};

void teclado_init()
{
	TECLADO->DDR = 0x0F;
	TECLADO->PORT = 0xFF;
}

uint8_t ler_teclado()
{
	uint8_t n, j, tecla=0xFF, linha;

	for(n=0;n<3;n++)
	{
		CLR_BIT(COLUNA,n);			//apaga o bit da coluna (varredura)
		_delay_ms(10);				//atraso para uma varredura mais lenta, tamb�m elimina o ru�do da tecla
		linha = LINHA >> 4;			//l� o valor das linhas

		for(j=0;j<4;j++)			//testa as linhas
		{
    		if(!TST_BIT(linha,j))	//se foi pressionada alguma tecla, decodifica e retorna o valor
			{
				tecla = pgm_read_byte(&teclado[j][n]);	//decodifica o valor para a tecla
				while(!TST_BIT(LINHA>>4,j));			//para esperar soltar a tecla
			}
		}
		SET_BIT(COLUNA,n);			//ativa o bit zerado anteriormente
	}
	return tecla;					//retorna o valor 0xFF se nenhuma tecla foi pressionada
}
