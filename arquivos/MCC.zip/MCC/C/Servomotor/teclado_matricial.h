/*
 * teclado_hex.h
 *
 *  Created on: 15 de mai de 2019
 *      Author: Tanaka
 */

#ifndef TECLADO_MATRICIAL_H_
#define TECLADO_MATRICIAL_H_

#define TECLADO GPIO_D
#define COLUNA PORTD
#define LINHA PIND

/**
  * @brief  Configura hardware do teclado.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void teclado_init();

/**
  * @brief  Faz a leitura do teclado.
  * @param	Nenhum
  *
  * @retval Tecla pressionada.
  */
uint8_t ler_teclado();

#endif /* TECLADO_MATRICIAL_H_ */
