/*
 * main.c
 *
 *  Created on: 15 de mai de 2019
 *      Author: Tanaka
 */

#include <avr/interrupt.h>
#include <avr/io.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "lib/bits.h"
#include "lib/avr_gpio.h"
#include "lib/avr_timer.h"
#include "servomotor.h"
#include "teclado_matricial.h"
#include "lcd.h"

int main(){

	uint8_t tecla;

	servo_hardware_init();
	teclado_init();
	FILE *lcd_stream = inic_stream();
	inic_LCD_4bits();
	/* Vai para primeira linha/coluna */
	cmd_LCD(0x84,0);
	/* Imprime msg */
	fprintf(lcd_stream,"ANGULO:");
	duty_cycle(0);


	while(1)
	{

		cmd_LCD(0xC6, 0);
		tecla = ler_teclado();
		angulo(tecla);
	}
}
