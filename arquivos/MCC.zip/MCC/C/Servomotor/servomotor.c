/*
 * servomotor.c
 *
 *  Created on: 15 de mai de 2019
 *      Author: Tanaka
 */

#include <avr/interrupt.h>
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>

#include "lib/bits.h"
#include "lib/avr_gpio.h"
#include "lib/avr_timer.h"
#include "servomotor.h"
#include "lcd.h"

volatile uint8_t i = 0, valores[3];

void servo_hardware_init()
{
	/*valor do topo de contagem para frequencia de 50Hz*/
	TIMER_1->ICR = TOP;
	/*Fast PWM com ICR1 como topo*/
	TIMER_1->TCCRA = SET(WGM11) | SET(COM1B1);
	TIMER_1->TCCRB = SET(WGM13) | SET(WGM12) | SET(CS11);

	SERVO_PORT->DDR |= SET(SERVO_CTRL);
}

void duty_cycle(uint16_t angulo)
{
	uint16_t duty = 0;

	if (angulo <= 180)
	{
		duty = ((100*angulo)/9)+2000;
		TIMER_1->OCRB = duty;
	}
	else
	{
		TIMER_1->OCRB = 2000;
	}
}

void angulo(uint8_t t)
{
	FILE *lcd_stream = inic_stream();

	if(t != 255)
	{
		if(i > 2)
		{
			i = 0;
		}

		if(t == '\n')
		{
			duty_cycle(strtoul(valores, NULL, 10));

			for(i = 0; i<=2; i++)
			{
				valores[i] = 0;
			}
			fprintf(lcd_stream,"%c%c%c", valores[0],valores[1],valores[2]);
		}

		else
		{
			valores[i] = t;
			fprintf(lcd_stream,"%c%c%c", valores[0],valores[1],valores[2]);
			i++;
		}
	}
}
