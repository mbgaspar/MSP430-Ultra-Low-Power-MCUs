/*
 * temporizador.h
 *
 * Created: 29/04/2019 14:38:09
 *  Author: Tanaka
 */ 


#ifndef TEMPORIZADOR_H_
#define TEMPORIZADOR_H_

/**
  * @brief  Configura hardware do ADC.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void adc_init();

/**
  * @brief  Configura hardware do timer0.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void timer0_hardware_init();


#endif /* TEMPORIZADOR_H_ */