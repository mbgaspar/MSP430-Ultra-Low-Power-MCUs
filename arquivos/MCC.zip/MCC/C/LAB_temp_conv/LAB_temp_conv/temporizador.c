/*
 * temporizador.c
 *
 * Created: 29/04/2019 14:38:23
 *  Author: Tanaka
 */ 
#define F_CPU 16000000UL

#include "avr_gpio.h"
#include "avr_adc.h"
#include "avr_timer.h"
#include "bits.h"

void adc_init()
{

	/* Ref externa no pino AVCC com capacitor de 100n em VREF.
	 * Habiltia��o apenas no Canal 0 */
	ADCS->AD_MUX = SET(REFS0);
	/* Habilita AD:
	 * Convers�o cont�nua
	 * IRQ ativo
	 * Prescaler de 128 */
	ADCS->ADC_SRA = SET(ADEN)  |	//ADC Enable
					SET(ADSC)  | 	// ADC Start conversion
					SET(ADATE) |	// ADC Auto Trigger
					SET(ADPS0) | SET(ADPS1) | SET(ADPS2) | //ADPS[0..2] AD Prescaler selection
					SET(ADIE); 		//AD IRQ ENABLE

	/* Desabilita hardware digital de PC0 */
	ADCS->DIDr0.BITS.ADC0 = 1;

}

void timer0_hardware_init()
{
	/* Acesso indireto por struct e bit field: com avr_timer.h */
	TIMER_0->TCCRA = 0;
	TIMER_0->TCCRB = SET(CS02);
	TIMER_IRQS->TC0.BITS.OCIEA = 1;
	TIMER_IRQS->TC0.BITS.OCIEB = 1;
}
