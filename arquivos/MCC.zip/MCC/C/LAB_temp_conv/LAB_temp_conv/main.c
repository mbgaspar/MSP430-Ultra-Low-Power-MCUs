/*
 * LAB_temp_conv.c
 *
 * Created: 29/04/2019 14:04:45
 * Author : Tanaka
 */ 

#define F_CPU 16000000UL

#include <avr/io.h>
#include <avr/interrupt.h>

#include "avr_gpio.h"
#include "avr_adc.h"
#include "avr_timer.h"
#include "bits.h"
#include "temporizador.h"

#define SAIDAS GPIO_B
#define PINO_A PB0
#define PINO_B PB1

volatile uint8_t i;
volatile uint16_t valor_ADC;

int main(void)
{
    /* PB0 e PB1 como sa�das */
    SAIDAS->DDR = SET(PINO_A)|SET(PINO_B);
	/* Inicializa o converor AD */
	adc_init();
	/* Inicializa o timer 0 */
	timer0_hardware_init();
	/* Ativa todos IRQs */
	sei();
	
	i = 0;
	
    while (1) 
    {
		/*(((valor_ADC*8/1024)*127)/10+13) express�o inicial
			(8/1024)*127 = 1
		*/
		/*Usando o meio de escala como referencia,
		 + ou - a raz�o da tens�o lida pelo ADC com limite de 80% + 10%*/
		OCR0A = 127-((valor_ADC/10)+13);
		OCR0B = 127+((valor_ADC/10)+13);
    }
}

ISR(ADC_vect)
{
	valor_ADC = ADC;
}

ISR(TIMER0_COMPA_vect)
{
	SET_BIT(SAIDAS->PORT,i);
}

ISR(TIMER0_COMPB_vect)
{
	CLR_BIT(SAIDAS->PORT,i);
	i++;
	if(i==2)
	{
		i=0;
	}
}