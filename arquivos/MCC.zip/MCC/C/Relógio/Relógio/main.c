/*
 * Relógio.c
 *
 * Created: 01/05/2019 10:18:56
 * Author : Tanaka
 */ 

#define F_CPU 16000000UL

#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <avr/io.h>

#include "avr_gpio.h"
#include "avr_timer.h"
#include "display.h"
#include "relogio.h"
#include "bits.h"

volatile uint8_t valores[4];
volatile uint8_t seg = 0;
volatile uint8_t ajuste = 0;
volatile uint8_t i = 0;


int main(void)
{
	timer0_hardware_init();
	display_init();
	timer1_hardware_init();
	config_ajuste();
	
	sei();
	 
    while (1) 
    {
		if(seg==60)
		{
			valores[0]++;
			seg = 0;
		}
		
		if(valores[0]==10)
		{
			valores[1]++;
			valores[0] = 0;
		}
		
		if(valores[1]==6)
		{
			valores[2]++;
			valores[1] = 0;
		}
		
		if(valores[2]==10)
		{
			valores[3]++;
			valores[2] = 0;
		}
		
		if((valores[3]==2) & (valores[2]==4))
		{
			valores[3] = 0;
			valores[2] = 0;
		}
    }
}

ISR(TIMER1_OVF_vect)
{
	seg++;
}

ISR(TIMER0_OVF_vect)
{
	display_write(valores[i], i);
	i++;
	if(i==4)
	{
		i = 0;
	}
}

ISR(INT0_vect)
{
	ajuste++;
	if(ajuste==2)
	{
		ajuste = 0;
	}
}

ISR(INT1_vect)
{
	if(ajuste==0)
	{
		valores[0]++;
	}
	if(ajuste==1)
	{
		valores[2]++;
	}
}