/*
 * relogio.c
 *
 * Created: 01/05/2019 10:23:04
 *  Author: Tanaka
 */ 

#define F_CPU 16000000UL

#include "avr_gpio.h"
#include "avr_timer.h"
#include "bits.h"

#define BTN_SELETOR PD2
#define BTN_AJUSTE PD3
#define BTN_PORT GPIO_D

void timer1_hardware_init()
{
	/* Acesso indireto por struct e bit field: com avr_timer.h */
	TIMER_1->TCCRA = 0;
	/*preescaler de 256.*/
	TIMER_1->TCCRB = SET(CS12); 
	TIMER_IRQS->TC1.BITS.TOIE = 1;
	/*estouro de contagem para que a interrup��o aconte�a acada 1s usando o preescaler em 256
	  t = fclock/(preescaler*topocontagem)*/
	ICR1 = 62500;
}

void config_ajuste()
{
	BTN_PORT->DDR = 0x00;
	BTN_PORT->PORT = SET(BTN_SELETOR)|SET(BTN_AJUSTE);
	/* Configura��o IRQ externas: INT0 e INT1 na borda de descida */
	EICRA = (1 << ISC01) | (1 << ISC11);
	/* Habilita IRQ do perif�rico */
	EIMSK = (1 << INT1)  | (1 << INT0);
}