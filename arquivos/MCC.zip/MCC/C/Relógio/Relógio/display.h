/*
 * display.h
 *
 * Created: 01/05/2019 10:23:58
 *  Author: Tanaka
 */ 


#ifndef DISPLAY_H_
#define DISPLAY_H_

#define COM_ANODO
//#define COM_CATODO

#define DISPLAY_PORT GPIO_C
#define SELETOR_DISPLAY GPIO_B
#define SELETOR_0 PB0
#define SELETOR_1 PB1
#define SELETOR_2 PB2
#define SELETOR_3 PB3

/**
  * @brief  Configura hardware.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void display_init();

/**
  * @brief  Escrevre no display de 7 segmentos.
  * @param	data: valor sem decimal sem convers�o. Dados
  * 			s�o convertidos internamente e o display a ser ligado.
  *
  * @retval Nenhum.
  */
void display_write(uint8_t data, uint8_t bit);

/**
  * @brief  Configura timer0.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void timer0_hardware_init();

#endif /* DISPLAY_H_ */