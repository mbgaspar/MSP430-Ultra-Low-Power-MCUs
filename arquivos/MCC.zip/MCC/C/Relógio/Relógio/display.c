/*
 * display.c
 *
 * Created: 01/05/2019 10:23:42
 *  Author: Tanaka
 */ 
#define F_CPU 16000000UL

#include <avr/pgmspace.h>
#include <avr/interrupt.h>

#include "avr_gpio.h"
#include "avr_timer.h"
#include "display.h"
#include "bits.h"

/* Tabela de convers�o em flash: Anodo comum */
#ifdef COM_ANODO
const uint8_t convTable[] PROGMEM = {0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02,
0x78, 0x00, 0x18, 0x08, 0x03, 0x46, 0x21, 0x06, 0x0E};
#endif

/* Tabela de convers�o em flash: Catodo comum */
#ifdef COM_CATODO
const uint8_t convTable[] PROGMEM = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07,
0x7F, 0x67, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71};
#endif


void display_init() 
{
	/* Configura��o de portas */
	DISPLAY_PORT->DDR = 0xFF;
	SELETOR_DISPLAY->DDR = SET(SELETOR_0)|SET(SELETOR_1)|SET(SELETOR_2)|SET(SELETOR_3);
	
}

void display_write(uint8_t data, uint8_t bit)
{
	SELETOR_DISPLAY->PORT = 0;
	DISPLAY_PORT->PORT = 0xFF;
	/* Escreve no display */
	DISPLAY_PORT->PORT = pgm_read_byte(&convTable[data]);
	GPIO_SetBit(SELETOR_DISPLAY, bit);
}

void timer0_hardware_init()
{
	/* Acesso indireto por struct e bit field: com avr_timer.h */
	TIMER_0->TCCRA = 0;
	TIMER_0->TCCRB = SET(CS02);
	TIMER_IRQS->TC0.BITS.TOIE = 1;
}
