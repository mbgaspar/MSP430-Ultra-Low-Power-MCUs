/*
 * relogio.h
 *
 * Created: 01/05/2019 10:22:48
 *  Author: Tanaka
 */ 


#ifndef RELOGIO_H_
#define RELOGIO_H_


/**
  * @brief  Configura timer1.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void timer1_hardware_init();

/**
  * @brief  Configura hardware para os bot�es de ajuste.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void config_ajuste();


#endif /* RELOGIO_H_ */