/*
 * pwm.c
 *
 *  Created on: 4 de jul de 2019
 *      Author: Tanaka
 */
#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#include "bits.h"
#include "avr_timer.h"
#include "avr_gpio.h"
#include "pwm.h"

void pwm_init()
{
	/* PB3: pino OC2A como sa�da */
	GPIO_D->DDR |= SET(PD3);

	/* Table 15-6.  Compare Output Mode, Fast PWM Mode */
	/* COM0B1   COM0B0  Desc:
	    0       0       Normal port operation, OC0A disconnected.
	    0       1       Reserved
	    1       0       Clear OC2A on Compare Match, set OC2A at BOTTOM (non-inverting mode)
	    1       1       Set OC2A on Compare Match, clear OC2A at BOTTOM (inverting mode).*/

	/* WGM02, WGM01 WGM00 setados: modo PWM r�pido com TOP em OCRA */
	TIMER_2->TCCRA = SET(WGM21) | SET(WGM20) | SET(COM2B1);
	TIMER_2->TCCRB = SET(WGM22) | SET(CS21);

	/* OCRA define frequ�ncia do PWM */
	TIMER_2->OCRA = TOP;
}

void duty_cycle(uint8_t ciclo)
{	
		if(ciclo<=100)
		{
			TIMER_2->OCRB = (ciclo*TOP)/100;
		}
			
		else
		{
			TIMER_2->OCRB = TOP;
		}
}
