/*
 * main_pwm.c
 *
 *  Created on: Apr 12, 2018
 *      Author: Renan Augusto Starke
 *      Insituto Federal de Santa Catarina
 */
#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "bits.h"
#include "avr_timer.h"
#include "avr_gpio.h"
#include "pwm.h"



int main(){

	uint8_t valor_pwm = 0;

	/* Configura timer em modo PWM */
	pwm_init();

	while (1){
		duty_cycle(valor_pwm);
		valor_pwm+=10;
		_delay_ms(1000);
	}
	
	return 0;
}
