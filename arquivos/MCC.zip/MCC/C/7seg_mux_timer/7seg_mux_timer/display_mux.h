/*
 * display_mux.h
 *
 * Created: 16/04/2019 08:08:38
 *  Author: Tanaka
 */ 


#ifndef DISPLAY_MUX_H_
#define DISPLAY_MUX_H_

#define SELETOR_DISPLAY GPIO_B
#define SELETOR_0 PB0
#define SELETOR_1 PB1
#define SELETOR_2 PB2
#define SELETOR_3 PB3

/**
  * @brief  Configura timer0.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void timer0_hardware_init();
/**
  * @brief  Configura hardware.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void init_seletor();

/**
  * @brief  Desliga os displays de 7seg.
  * @param	porta seletora do display a ser desligado
  *
  * @retval Nenhum.
  */
void desliga_displays();

/**
  * @brief  Liga o display.
  * @param	dado do display e a porta seletora do display a ser ligado
  *
  * @retval Nenhum.
  */
void liga_display(uint8_t dado, uint8_t bit);



#endif /* DISPLAY_MUX_H_ */