/*
 * 7seg_mux_timer.c
 *
 * Created: 16/04/2019 08:01:24
 * Author : Tanaka
 */ 

#include <avr/io.h>

#include "bits.h"
#include "avr_gpio.h"
#include "avr_timer.h"
#include "avr_extirq.h"
#include "led_display.h"
#include "display_mux.h"

/* Quando habilitado IRQ de overflow no timer 0*/
ISR(TIMER0_OVF_vect)
{
	desliga_displays();
	
	liga_display(e, indice);
	indice++;
}


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

