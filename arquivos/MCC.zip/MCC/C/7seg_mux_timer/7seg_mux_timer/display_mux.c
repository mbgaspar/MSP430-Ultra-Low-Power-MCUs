/*
 * display_mux.c
 *
 * Created: 16/04/2019 08:09:04
 *  Author: Tanaka
 */ 

#include <avr/interrupt.h>

#include "bits.h"
#include "avr_gpio.h"
#include "avr_timer.h"
#include "avr_extirq.h"
#include "led_display.h"
#include "display_mux.h"


void timer0_hardware_init()
{
	/* Acesso indireto por struct e bit field: com avr_timer.h */
	TIMER_0->TCCRA = 0;
	TIMER_0->TCCRB = SET(CS02) | SET(CS00);
	TIMER_IRQS->TC0.BITS.TOIE = 1;
}

void desliga_displays()
{
	SELETOR_DISPLAY->PORT = SET(SELETOR_0)|SET(SELETOR_1)|SET(SELETOR_2)|SET(SELETOR_3);
	DISPLAY_PORT->PORT = 0xFF;
}

void liga_display(uint8_t dado, uint8_t bit)
{
	display_write(dado);
	GPIO_ClrBit(SELETOR_DISPLAY, bit);
}