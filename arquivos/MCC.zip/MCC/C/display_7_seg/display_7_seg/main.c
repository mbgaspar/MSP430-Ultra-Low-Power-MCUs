/*
 * 01_main_simple_display.c
 *
 *  Created on: Aug 16, 2018
 *      Author: Renan Augusto Starke
 *      Instituto Federal de Santa Catarina
 */

#define F_CPU 16000000UL

/* Bibliotecas C e AVR */
#include <avr/io.h>
#include <util/delay.h>

/* Bibliotecas customizadas */
#include "avr_gpio.h"
#include "bits.h"
#include "led_display.h"

#define BTN_PORT GPIO_B
#define BTN_PIN PB0

/**
  * @brief  Configura hardware.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void hardware_init(){

	/* Melhor documenta��o: macros */
	BTN_PORT->PORT = SET(BTN_PIN);
}


int main(){
	/* Configura hardware do projeto */
	display_init();
	/* Configura hardware do projeto */
	hardware_init();
	
	uint8_t i=0;

	while (1)
	{

		display_write(i);
		if(!GPIO_PinTstBit(BTN_PORT, BTN_PIN))
		{
			i++;
			if(i==0x10)
			{
				i=0;
			}
			_delay_ms(250);
		}
	}

	return 0;

}
