/*
 * main.c
 *
 *  Created on: 29 de mai de 2019
 *      Author: Tanaka
 */

#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>
#include <avr/interrupt.h>

#include "lib/bits.h"
#include "lib/avr_gpio.h"
#include "lib/avr_timer.h"
#include "servomotor.h"
#include "lcd.h"
#include "ntc.h"

int main(){

	timer0_hardware_init();
	adc_init();
	servo_hardware_init();
	inic_LCD_4bits();
	sei();
	duty_cycle(0);

	uint16_t temp = 0;
	uint16_t abertura = 0;

	while(1)
	{
		temp = conv_temperatura();
		abertura = define_estado(temp);
		imprimi_dados(temp, abertura);
	}
}
