/*
 * ntc.h
 *
 *  Created on: 29 de mai de 2019
 *      Author: Tanaka
 */

#ifndef NTC_H_
#define NTC_H_

/**
  * @brief  Configura hardware do timer 0.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void timer0_hardware_init();

/**
  * @brief  Configura hardware do ADC.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void adc_init();

/**
  * @brief  Converte a leitura ADC em temperatura.
  * @param	Nenhum
  *
  * @retval Valor da convers�o.
  */
uint16_t conv_temperatura();

/**
  * @brief  Define o angulo de abertura do servomotor dependendo da temperatura.
  * @param	Temperatura
  *
  * @retval Angulo de abertura do servomotor.
  */
uint16_t define_estado(uint16_t temp);

/**
  * @brief  Escreve no LCD a temperatura e o angulo do servomotor.
  * @param	Temperatura e angulo
  *
  * @retval Nenhum.
  */
void imprimi_dados(uint16_t temp, uint16_t angulo);

#endif /* NTC_H_ */
