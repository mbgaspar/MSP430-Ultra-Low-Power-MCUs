/*
 * ntc.c
 *
 *  Created on: 29 de mai de 2019
 *      Author: Tanaka
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>

#include "lib/avr_gpio.h"
#include "lib/avr_timer.h"
#include "lib/avr_adc.h"
#include "lib/bits.h"
#include "lcd.h"
#include "servomotor.h"
#include "ntc.h"

volatile uint16_t soma = 0, buffer[4];
volatile uint8_t i = 0;

void f_angulo_1(void);
void f_angulo_2(void);
void f_angulo_3(void);
void f_angulo_4(void);
void f_angulo_5(void);
void f_angulo_6(void);


/* Defini��o dos estados */
typedef enum {
	STATE_A,
	STATE_B,
	STATE_C,
	STATE_D,
	STATE_E,
	STATE_F,
	NUM_STATES
} state_t;

/* Defini��o da estrutura mantenedora do vetor de estados */
typedef struct {
	state_t myState;
	void (*func)(void);
}fsm_t;

/* Mapeamento entre estado e fun��es */
fsm_t myFSM[] = {
	{ STATE_A, f_angulo_1 },
	{ STATE_B, f_angulo_2 },
	{ STATE_C, f_angulo_3 },
	{ STATE_D, f_angulo_4 },
	{ STATE_E, f_angulo_5 },
	{ STATE_F, f_angulo_6 },
};

volatile state_t curr_state = STATE_A;

void timer0_hardware_init()
{
	/* Acesso indireto por struct e bit field: com avr_timer.h *
	 * */
	TIMER_0->TCCRA = 0;
	TIMER_0->TCCRB = SET(CS02);
	TIMER_IRQS->TC0.BITS.TOIE = 1;
	GPIO_B->DDR |= 0x01;
}

void adc_init()
{
	/* Ref externa no pino AVCC com capacitor de 100n em VREF.
	 * Habiltia��o apenas no Canal 0 */
	ADCS->AD_MUX = SET(REFS0);
	/* Habilita AD:
	 * Convers�o cont�nua
	 * IRQ ativo
	 * Prescaler de 8 */
	ADCS->ADC_SRA = SET(ADEN)  |	//ADC Enable
					SET(ADSC)  | 	// ADC Start conversion
					SET(ADATE) |	// ADC Auto Trigger
					SET(ADPS0) | SET(ADPS1) | //ADPS[0..2] AD Prescaler selection
					SET(ADIE); 		//AD IRQ ENABLE

	/* Auto trigger in timer0 overflow */
	ADCS->ADC_SRB = SET(ADTS2);

	/* Desabilita hardware digital de PC0 */
	ADCS->DIDr0.BITS.ADC0 = 1;

}

ISR(ADC_vect)
{
	uint16_t valor = ADC;
	soma = soma - buffer[i];
	buffer[i] = valor;
	soma = soma + valor;
	i++;
	i = i & 0x03; // substitui if(i > 3)
}

ISR(TIMER0_OVF_vect)
{
	GPIO_CplBit(GPIO_B, 0);
}

uint16_t conv_temperatura()
{
	uint16_t media_adc = (soma>>2);
	/* Equa��o de temperatura tirada da tabela do NTC feita em simula��o:
	 *  t = 6*e-5*ADC^2-0,2478*ADC+195,8
	 *  a equa��o foi multiplicada por 100 para usar 2 casas decimais
	 *  como na primeira vari�vel temos 6*ADC^2/1000 para evitar o estouro dos 16 bits da
	 *  vari�vel dividiu-se por 100 primeiro e depois por 10*/
	return ((6*media_adc)/100*media_adc)/10-(25*media_adc)+19580;
}

uint16_t define_estado(uint16_t temp)
{
	uint16_t angulo = 0;

	if(temp < 3000)
	{
		curr_state = STATE_A;
		angulo = 150;
	}
	else if((temp > 3000) & (temp < 5000))
	{
		curr_state = STATE_B;
		angulo = 300;
	}
	else if((temp > 5000) & (temp < 7000))
	{
		curr_state = STATE_C;
		angulo = 450;
	}
	else if((temp > 7000) & (temp < 9000))
	{
		curr_state = STATE_D;
		angulo = 600;
	}
	else if((temp > 9000) & (temp < 12000))
	{
		curr_state = STATE_E;
		angulo = 750;
	}
	else if((temp > 12000))
	{
		curr_state = STATE_F;
		angulo = 900;
	}

	(*myFSM[curr_state].func)();
	return angulo;
}

void imprimi_dados(uint16_t temp, uint16_t angulo)
{
	FILE *lcd_stream = inic_stream();
	/* Vai para primeira linha/coluna */
	cmd_LCD(0x80,0);
	/* Imprime msg */
	fprintf(lcd_stream,"TEMP: %d,%d", temp/100, temp%100);
	/* Vai para segunda linha/primeira coluna */
	cmd_LCD(0xC0,0);
	fprintf(lcd_stream,"ANGULO: %d,%d", angulo/10, angulo%10);
}

void f_angulo_1(void){
	duty_cycle(15);
}

void f_angulo_2(void){
	duty_cycle(30);
}

void f_angulo_3(void){
	duty_cycle(45);
}

void f_angulo_4(void){
	duty_cycle(60);
}

void f_angulo_5(void){
	duty_cycle(75);
}

void f_angulo_6(void){
	duty_cycle(90);
}
