/*
 * servomotor.h
 *
 *  Created on: 15 de mai de 2019
 *      Author: Tanaka
 */

#ifndef SERVOMOTOR_H_
#define SERVOMOTOR_H_

#define SERVO_PORT GPIO_B
#define SERVO_CTRL PB2
#define TOP 40000

/**
  * @brief  Configura hardware para funcionamento do servomotor.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void servo_hardware_init();
/**
  * @brief  Transforma o angulo na raz�o c�clica.
  * @param	Angulo.
  *
  * @retval Nenhum.
  */
void duty_cycle(uint16_t angulo);

#endif /* SERVOMOTOR_H_ */
