/*
 * pisca_seq.c
 *
 * Created: 11/03/2019 13:54:39
 * Author : Tanaka
 */ 

#define F_CPU 16000000

/* Bibliotecas C e AVR */
#include <avr/io.h>
#include <util/delay.h>

/* Bibliotecas customizadas */
#include "lib/avr_gpio.h"
#include "lib/bits.h"

#define LED_PORT GPIO_D


/**
  * @brief  Configura hardware.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void hardware_init(){

	/* Melhor documenta��o: macros */
	LED_PORT->DDR = 0xFF;
}


int main(){
	/* Configura hardware do projeto */
	hardware_init();
	
	uint8_t i;

	while (1)
	{
		for(i=0; i<9; i++)
		{
			LED_PORT->PORT = SET(i);
			_delay_ms(250);
		}
		
	}

	return 0;

}