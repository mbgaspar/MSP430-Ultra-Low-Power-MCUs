/*
 * rtc.c
 *
 *  Created on: 12 de jun de 2019
 *      Author: Tanaka
 */

#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include "lib/avr_twi_master.h"
#include "rtc.h"

#define DS1302_RD_ADDR 0xD1	/* 1101 0001(R/W) -> Read Address */
#define DS1302_WR_ADDR 0xD0	/* 1101 0000(R/W) -> Write Address */

volatile uint8_t h[3];

void zera_ponteiro()
{
	/* Vetor para dados do I2C */
	uint8_t packge[8] = {0};

	/* Configura Ponteiro do DS1307 em 0x00 pois ele � *
	 * automaticamente incrementado a cada leitura     */
	packge[0] = DS1302_WR_ADDR;	/* Endere�o I2C de escrita */
	packge[1] = 0x00;			/* Endere�o inicial da SRAM do RTC: segundos, minutos */
	TWI_Start_Transceiver_With_Data(packge,2);
}

uint8_t *pega_horas()
{
	/* Vetor para dados do I2C */
	uint8_t packge[8] = {0};

	/* Obt�m Hora, minuto e segundo */
	packge[0] = DS1302_RD_ADDR;
	packge[1] = 0x00;
	/* msgSize deve ser a quantidade de dados que se deseja *
	 * receber mais 1 (byte inicial do endere�o pois o clock
	 * deve ser enviado pelo l�der do barramento i2c
	 */
	TWI_Start_Transceiver_With_Data(packge,4);

	/* Copia os dados recebidos para um buffer */
	TWI_Get_Data_From_Transceiver(packge,4);

	h[2] = packge[1];
	h[1] = packge[2];
	h[0] = packge[3];

	return h;
}
