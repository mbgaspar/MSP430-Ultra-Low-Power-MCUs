/*
 * main_rtc_i2c.c
 *
 *  Created on: Mar 27, 2018
 *      Author: Renan Augusto Starke
 *      Instituto Federal de Santa Catarina
 */

#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdio.h>
#include "lcd_i2c.h"
#include "lib/avr_usart.h"
#include "lib/avr_twi_master.h"
#include "rtc.h"

int main(){
	FILE *usart_stream = get_usart_stream();

	/* Debug */
	USART_Init(B9600);

	/* Inicializa modo l�der */
	TWI_Master_Initialise();
	sei();

	uint8_t *horas;

	for(;;) {

		zera_ponteiro();

		horas = pega_horas();

		fprintf(usart_stream,"%2x:%2x:%2x", horas[0], horas[1], horas[2]);
		fprintf(usart_stream,"\n\r");
		_delay_ms(1000);
	}

}
