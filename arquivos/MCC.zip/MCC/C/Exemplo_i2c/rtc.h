/*
 * rtc.h
 *
 *  Created on: 12 de jun de 2019
 *      Author: Tanaka
 */

#ifndef RTC_H_
#define RTC_H_

/**
  * @brief  Faz com que o ponteiro interno do rtc volte para 0.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void zera_ponteiro();


/**
  * @brief  Requesita a hora para o rtc.
  * @param	Nenhum
  *
  * @retval vetor com os valores recebidos do rtc.
  */
uint8_t *pega_horas();

#endif /* RTC_H_ */
