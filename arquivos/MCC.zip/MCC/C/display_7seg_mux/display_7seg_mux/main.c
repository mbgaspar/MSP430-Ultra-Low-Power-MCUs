/*
 * display_7seg_mux.c
 *
 * Created: 12/03/2019 08:02:42
 * Author : Tanaka
 */ 
#define F_CPU 16000000UL

/* Bibliotecas C e AVR */
#include <avr/io.h>
#include <util/delay.h>

/* Bibliotecas customizadas */
#include "avr_gpio.h"
#include "bits.h"
#include "led_display.h"
#include "display_mux.h"

int main(){
	/* Configura hardware do projeto */
	display_init();
	init_seletor();
	
	uint8_t a=0x0A, e=0x0E;

	while (1)
	{

		desliga_displays(SELETOR_1);
		desliga_displays(SELETOR_2);
		
		liga_display(e, SELETOR_1);
		_delay_ms(20);
		
		desliga_displays(SELETOR_1);
		liga_display(a, SELETOR_2);
		_delay_ms(20);		
	}

	return 0;

}

