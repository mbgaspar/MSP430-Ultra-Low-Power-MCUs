/*
 * display_mux.h
 *
 * Created: 12/03/2019 08:05:42
 *  Author: Tanaka
 */ 


#ifndef DISPLAY_MUX_H_
#define DISPLAY_MUX_H_

#define SELETOR_DISPLAY GPIO_B
#define SELETOR_1 PB0
#define SELETOR_2 PB1 

/**
  * @brief  Configura hardware.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void init_seletor();

/**
  * @brief  Desliga os displays de 7seg.
  * @param	porta seletora do display a ser desligado
  *
  * @retval Nenhum.
  */
void desliga_displays(uint8_t bit);

/**
  * @brief  Liga o display 1.
  * @param	dado do display 1 e a porta seletora do display a ser ligado
  *
  * @retval Nenhum.
  */
void liga_display(uint8_t dado, uint8_t bit);


#endif /* DISPLAY_MUX_H_ */