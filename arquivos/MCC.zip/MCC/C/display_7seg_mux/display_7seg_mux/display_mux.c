/*
 * display_mux.c
 *
 * Created: 12/03/2019 08:06:19
 *  Author: Tanaka
 */ 

#define F_CPU 16000000UL

#include <util/delay.h>

#include "display_mux.h"
#include "led_display.h"
#include "bits.h"
#include "avr_gpio.h"

void init_seletor()
{
	SELETOR_DISPLAY->DDR = SET(SELETOR_1)|SET(SELETOR_2);
}

void desliga_displays(uint8_t bit)
{
	SELETOR_DISPLAY->PORT = SET(bit);
	DISPLAY_PORT->PORT = 0xFF;
}

void liga_display(uint8_t dado, uint8_t bit)
{
	display_write(dado);
	GPIO_ClrBit(SELETOR_DISPLAY, bit);
}
