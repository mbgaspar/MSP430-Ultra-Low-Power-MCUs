/*
 * pisca3X3.c
 *
 * Created: 11/03/2019 13:45:40
 * Author : Tanaka
 */ 

#define F_CPU 16000000

/* Bibliotecas C e AVR */
#include <avr/io.h>
#include <util/delay.h>

/* Bibliotecas customizadas */
#include "lib/avr_gpio.h"
#include "lib/bits.h"

#define LED_PORT GPIO_B
#define LED_PIN	PB5


/**
  * @brief  Configura hardware.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void hardware_init(){

	/* Melhor documenta��o: macros */
	LED_PORT->DDR = SET(LED_PIN);
}


int main(){
	/* Configura hardware do projeto */
	hardware_init();
	
	uint8_t i;

	while (1)
	{
		for(i=3; i>0; i--)
		{
			GPIO_SetBit(LED_PORT, LED_PIN);
			_delay_ms(250);
			GPIO_ClrBit(LED_PORT, LED_PIN);
			_delay_ms(250);
		}
		
		for(i=3; i>0; i--)
		{
			GPIO_SetBit(LED_PORT, LED_PIN);
			_delay_ms(750);
			GPIO_ClrBit(LED_PORT, LED_PIN);
			_delay_ms(750);
		}
		
	}

	return 0;

}
