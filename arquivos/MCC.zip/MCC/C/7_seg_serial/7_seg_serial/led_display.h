/*
 * leddisplay.h
 *
 *  Created on: Aug 20, 2018
 *      Author: Renan Augusto Starke
 *      Instituto Federal de Santa Catarina
 */

#ifndef DISPLAY_LEDDISPLAY_H_
#define DISPLAY_LEDDISPLAY_H_

#define COM_ANODO
//#define COM_CATODO

/**
  * @brief  Busca na tabela de converção o valor para ligar o display.
  * @param	data: valor sem decimal sem conversão. Dados
  * 			são convertidos internamente.
  *
  * @retval Valor da tabela do display.
  */
uint8_t display_data_conv(uint8_t data);

#endif /* DISPLAY_LEDDISPLAY_H_ */
