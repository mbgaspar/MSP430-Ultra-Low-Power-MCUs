/*
 * display_7seg_serial.h
 *
 * Created: 31/03/2019 19:27:28
 *  Author: Tanaka
 */ 


#ifndef DISPLAY_7SEG_SERIAL_H_
#define DISPLAY_7SEG_SERIAL_H_

#define DISPLAY_PORT GPIO_B
#define D PB0
#define CLK	PB1
#define STB	PB2



/**
  * @brief  Configura interrup��es.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void interruption();

/**
  * @brief  Transforma em serial o valor que deve ser escrito no display de 7 segmentos.
  * @param	Dado da tabela de convers�o do display.
  *
  * @retval Nenhum.
  */
void display_serial(uint8_t data);

/**
  * @brief  Separa o primeiro e segundo numero hexa.
  * @param	Dado que deve aparecer no display
  *
  * @retval Nenhum.
  */
void display_serial_write(uint8_t data);


#endif /* DISPLAY_7SEG_SERIAL_H_ */