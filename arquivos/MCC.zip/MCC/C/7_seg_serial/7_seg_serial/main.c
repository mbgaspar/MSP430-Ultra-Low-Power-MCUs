/*
 * 7_seg_serial.c
 *
 * Created: 31/03/2019 19:14:58
 * Author : Tanaka
 */ 

#define F_CPU 16000000UL

#include <avr/interrupt.h>
#include <util/delay.h>
#include <avr/io.h>
#include <avr/pgmspace.h>

#include "display_7seg_serial.h"
#include "led_display.h"
#include "bits.h"
#include "avr_gpio.h"

volatile uint8_t x = 0;

ISR(INT0_vect)
{
	x++;
}


int main(void)
{
    interruption();
	DISPLAY_PORT->DDR = GPIO_SetBit(DISPLAY_PORT, CLK)| GPIO_SetBit(DISPLAY_PORT, D) | GPIO_SetBit(DISPLAY_PORT, STB);
	
    while (1) 
    {
		display_serial_write(x);
		_delay_ms(25);
    }
}

