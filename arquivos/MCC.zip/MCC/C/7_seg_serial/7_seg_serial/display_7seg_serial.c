/*
 * display_7seg_serial.c
 *
 * Created: 31/03/2019 19:27:04
 *  Author: Tanaka
 */ 
#define F_CPU 16000000UL

#include <avr/pgmspace.h>
#include <util/delay.h>
#include <avr/io.h>
#include <avr/interrupt.h>

#include "avr_gpio.h"
#include "led_display.h"
#include "display_7seg_serial.h"
#include "bits.h"

#define CLK_pulse() GPIO_SetBit(DISPLAY_PORT, CLK); _delay_us(10); GPIO_ClrBit(DISPLAY_PORT, CLK)
#define STB_pulse() GPIO_SetBit(DISPLAY_PORT, STB); _delay_us(10); GPIO_ClrBit(DISPLAY_PORT, STB)

void interruption()
{
	GPIO_D->DDR = 0x00;
	GPIO_D->PORT = (1 << PD2);

	EICRA = SET(ISC01); //interrup��o acionada por borda de descida.
	EIMSK = SET(INT0);	

	sei();
}

void display_serial(uint8_t data)
{
	uint8_t i = 8;
	uint8_t dado = display_data_conv(data);
	
	while(i != 0)
	{
		i--;
		TST_BIT(dado, i) ? GPIO_SetBit(DISPLAY_PORT, D) : GPIO_ClrBit(DISPLAY_PORT, D);
		CLK_pulse();
	}
}

void display_serial_write(uint8_t data)
{
	display_serial(data & 0x0F);
	display_serial(data >> 4);
	STB_pulse();
}