/*
 * servomotor.c
 *
 *  Created on: 15 de mai de 2019
 *      Author: Tanaka
 */
#define F_CPU 16000000UL

#include <avr/interrupt.h>
#include <avr/io.h>
#include <stdio.h>
#include <stdlib.h>

#include "lib/bits.h"
#include "lib/avr_gpio.h"
#include "lib/avr_timer.h"
#include "servomotor.h"


void servo_hardware_init()
{
	/*valor do topo de contagem para frequencia de 50Hz*/
	TIMER_1->ICR = TOP;
	/*Fast PWM com ICR1 como topo*/
	TIMER_1->TCCRA = SET(WGM11) | SET(COM1B1);
	TIMER_1->TCCRB = SET(WGM13) | SET(WGM12) | SET(CS11);

	SERVO_PORT->DDR |= SET(SERVO_CTRL);
}

void duty_cycle(uint16_t angulo)
{
	uint16_t duty = 0;

	duty = ((100*angulo)/9)+2000;
	TIMER_1->OCRB = duty;
}

