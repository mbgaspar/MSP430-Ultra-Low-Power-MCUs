/*
 * onda_quadrada.c
 *
 * Created: 29/03/2019 08:47:49
 * Author : Tanaka
 */ 

#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#include "bits.h"
#include "avr_gpio.h"

#define ONDA_PORT GPIO_B
#define ONDA_SAIDA PB5

/* Modificador vol�til: vari�vel alterada fora
 * do fluxo cont�nuo de opera��o                */
volatile uint8_t seletor = 1;

ISR(INT0_vect)
{
	seletor++;
}

ISR(INT1_vect)
{
	_delay_ms(500);
}


int main(){
	/* Configura hardware do projeto */
	ONDA_PORT->DDR = SET(ONDA_SAIDA);
	
	/* PINOS PD2 e PD3 como entrada e pull ups */
	GPIO_D->DDR  = ~((1 << PD2) | (1 << PD3));   
	GPIO_D->PORT = (1 << PD2) | (1 << PD3);
	
	/* Configura��o IRQ externas: INT0 e INT1 na borda de descida */
	EICRA = (1 << ISC01) | (1 << ISC11);
	/* Habilita IRQ do perif�rico */
	EIMSK = (1 << INT1)  | (1 << INT0);

	/* Habilita IRQ global */
	sei();

	while (1)
	{
		
		switch (seletor)
		{
			case 1:
			//onda de periodo 1ms
			GPIO_SetBit(ONDA_PORT, ONDA_SAIDA);
			_delay_us(500);
			GPIO_ClrBit(ONDA_PORT, ONDA_SAIDA);
			_delay_us(500);
			break;

			case 2:
			//onda de periodo 100ms
			GPIO_SetBit(ONDA_PORT, ONDA_SAIDA);
			_delay_ms(50);
			GPIO_ClrBit(ONDA_PORT, ONDA_SAIDA);
			_delay_ms(50);
			break;
			
			case 3:
			//onda de periodo 1000ms
			GPIO_SetBit(ONDA_PORT, ONDA_SAIDA);
			_delay_ms(500);
			GPIO_ClrBit(ONDA_PORT, ONDA_SAIDA);
			_delay_ms(500);
			break;
		}
		
		if(seletor == 4)
		{
			seletor = 1;
		}	
		
	}

	return 0;

}
