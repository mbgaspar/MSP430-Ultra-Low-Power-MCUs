/*
 * 01_main_simple_gpio.c
 *
 *  Created on: Aug 16, 2018
 *      Author: Renan Augusto Starke
 *      Instituto Federal de Santa Catarina
 */

#define F_CPU 16000000UL

/* Bibliotecas C e AVR */
#include <avr/io.h>
#include <util/delay.h>

/* Bibliotecas customizadas */
#include "lib/avr_gpio.h"
#include "lib/bits.h"

#define LED_PORT GPIO_B
#define LED_PIN	PB5

#define BTN_PORT GPIO_B
#define BTN_PIN PB0

/**
  * @brief  Configura hardware.
  * @param	Nenhum
  *
  * @retval Nenhum.
  */
void hardware_init(){

	/* Melhor documenta��o: macros */
	LED_PORT->DDR = SET(LED_PIN);
	BTN_PORT->PORT = SET(BTN_PIN);
}


int main(){
	/* Configura hardware do projeto */
	hardware_init();

	while (1){		
		if(!GPIO_PinTstBit(BTN_PORT, BTN_PIN))
		{
			GPIO_CplBit(LED_PORT, LED_PIN);
		}
	}

	return 0;

}
