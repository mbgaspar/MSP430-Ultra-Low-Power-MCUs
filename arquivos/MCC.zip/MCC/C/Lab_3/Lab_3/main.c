/*
 * 02_main_simple_lcd.c
 *
 *  Created on: Aug 28, 2018
 *      Author: Renan Augusto Starke
 *      Instituto Federal de Santa Catarina
 */
#define F_CPU 16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#include <stdio.h>

#include "avr_gpio.h"
#include "lcd.h"

#define BTN_PORT GPIO_D
#define BTN_PIN PD7

volatile uint8_t x = 0;

ISR(INT0_vect)
{
	x++;
}

int main(){

	
	/* PINOS PD2 e PD7 como entrada e pull ups */
	GPIO_D->DDR  = ~(1 << PD2)|(1 << PD7);
	GPIO_D->PORT = (1 << PD2)|(1 << PD7);

	/* Configura��o IRQ externas: INT0 e INT1 na borda de descida */
	EICRA = (1 << ISC01);
	/* Habilita IRQ do perif�rico */
	EIMSK = (1 << INT0);
	
	sei();

	FILE *lcd_stream = inic_stream();
	inic_LCD_4bits();

	while (1)
	{
		if(!GPIO_PinTstBit(BTN_PORT, BTN_PIN))
		{
			x++;
			_delay_ms(250);
		}
		
		/* Vai para primeira linha/coluna */
		cmd_LCD(0x87,0);
		/* Imprime msg */
		fprintf(lcd_stream,"%3d", x);
	}
}
