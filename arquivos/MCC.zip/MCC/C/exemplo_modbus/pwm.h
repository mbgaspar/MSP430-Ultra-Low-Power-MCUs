/*
 * pwm.h
 *
 *  Created on: 4 de jul de 2019
 *      Author: Tanaka
 */

#ifndef PWM_H_
#define PWM_H_

#define TOP 200

void pwm_init();

void duty_cycle(uint8_t ciclo);

#endif /* PWM_H_ */
