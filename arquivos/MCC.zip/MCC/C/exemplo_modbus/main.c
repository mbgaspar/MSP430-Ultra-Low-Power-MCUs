/*
 * main.c
 *
 *  Created on: 26 de jun de 2019
 *      Author: Tanaka
 */

#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>
#include <avr/interrupt.h>

#include "lib/avr_usart.h"
#include "lib/bits.h"
#include "lib/avr_gpio.h"
#include "modbus.h"
#include "DS1302.h"
#include "three_wire.h"
#include "pwm.h"


int main(){
	uint8_t *data;

	/* Inicializa hardware da USART */
	USART_Init(B9600);

	three_wire_init();
	pwm_init();

	sei();
	//write_minutes(21);
	//write_24hours(0x16);
	 //SET_BIT(GPIO_C->PORT, PC1);

	while(1)
	{
	   //data = 55;
		// data++;
		//data = get_seconds();
		// SET_BIT(GPIO_C->PORT, PC0);
	  //transmite_dado(data, 5);
	  //SET_BIT(GPIO_C->PORT, PC1);
	  //_delay_ms(250);
	  //data = get_minutes();
	 // _delay_ms(250);

	   data = le_dado(1);
	   duty_cycle(50);
	   //transmite_dado(data,0x06);
	  //transmite_dado(data+1, 6);
	   _delay_ms(1000);

	}


	return 0;
}
