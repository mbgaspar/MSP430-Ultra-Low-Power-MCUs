﻿﻿# Relatório Laboratório 1

Ariane Andréia Martins

Ednei Freiberger

---

## Item 1 - Verificação da função de atraso

### Período de 1ms
Obteve-se a precisão de 1ms no osciloscópio utilizando os cursores para realizar a medida

![Figura 1 - 1ms primeira medida](1ms_item1.0.bmp)

 Para comparar foi realizada a medida também através da opção 'Measure' do oscloscópio, resultando em 1,001ms

![Figura 2 - 1ms segunda medida](1ms_item1.bmp)


---

### Período de 100ms
Obteve-se a precisão de 101ms no osciloscópio utilizando os cursores para realizar a medida, porém percebeu-se que um dos cursores não foi bem posicionado gerando esse erro.

![Figura 3 - 100ms primeira medida](100ms_item1.0.bmp)

Através da opção 'Measure' do osciloscópio, o período medido foi de 100,1ms.

![Figura 4 - 100ms segunda medida](100ms_item1.bmp)

---
### Período de 1000ms
Obteve-se a medida de 1s (1000ms) através dos cursores do osciloscópio.
Devido o período elevado, não foi possível realizar a medida através da opção 'Measure' do osciloscópio.

![Figura 5 - 1000ms](1000ms_item1.bmp)


Criando essa função de atraso e avaliando ela através do osciloscópio, percebeu-se (apesar do posicionamento incorreto de um dos cursores) que a onda quadrada teve um período preciso, conforme o desejado, mostrando a importância de utilizar os microcontroladores para aplicações que precisam de resposta em tempo real, como um _airbag_ por exemplo.


---

# Item 2 - Interrupções externas 

A precisão dos sinais periódicos gerados não continua a mesma, sendo alterada quando ocorre uma interrupção externa, já que o main tem a menor prioridade.

![Figura 5 - Sinal periódico interrompido](interferencia.bmp)

Utilizando o modo de disparo por borda de descida, quando o botão é pressionado, assim que ocorre a borda de descida a interrupção é gerada.

Com a borda de subida, ao pressionar o botão, em teoria, tem-se nível lógico baixo, e seria necessário soltá-lo para ocorrer a borda de subida e gerar a interrupção. Mas na prática, mesmo não soltando o botão, a interrupção é gerada devido a sua trepidação, onde o sinal oscila, e na primeira borda de subida aciona a interrupção.

No modo de disparo da IRQ por nível (baixo), a interrupção irá ocorrer enquanto o botão estiver pressionado.


---
# Item 3 - Número de vezes que o botão é apertado

Para contar quantas vezes o botão foi pressionado, usando um laço para espera, foi necessário utilizar o _debounce_, pois a interferência causada pelo botão gera um erro na contagem. O _debounce_ funcionou bem. 

Ocorreram problemas ao implementar a contagem utilizando as interrupções externas por nível e por borda, pois a contagem por vezes estava errada, ou o Atmega não respondia nenhum comando.





